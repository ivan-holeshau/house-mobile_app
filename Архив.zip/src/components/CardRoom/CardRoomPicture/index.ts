import CardRoomPicture from "./CardRoomPictureContainer";

export default CardRoomPicture;