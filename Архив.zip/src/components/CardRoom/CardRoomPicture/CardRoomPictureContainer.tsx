import CardRoomPictureProps from "./CardRoomPicture";
import Picture from "./CardRoomPicture";

export default Picture;
