import CardRom from "./CardRoomContainer";

export default CardRom;
