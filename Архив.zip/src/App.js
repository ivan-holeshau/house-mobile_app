import React from 'react';
import CardRoom from "./components/CardRoom"
function App() {
  return (
    <div style={{height:'100vh'}}>
      <CardRoom/>
      <CardRoom/>
      <CardRoom/>
    </div>
  );
}

export default App;
